"""Current version of package downloaders."""
__version__ = "1.0.15"