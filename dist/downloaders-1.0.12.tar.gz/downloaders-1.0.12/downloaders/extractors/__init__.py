"""Module with methods to extract files."""
from .auto_extractor import AutoExtractor


__all__ = [
    "AutoExtractor"
]
