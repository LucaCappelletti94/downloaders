"""Module with the classes relative to downloading stuff."""
from .base_downloader import BaseDownloader

__all__ = [
    "BaseDownloader"
]
