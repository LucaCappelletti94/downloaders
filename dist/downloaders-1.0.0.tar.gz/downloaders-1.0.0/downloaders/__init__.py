"""Downloaders is a package to easily downloading stuff."""
from .downloaders import BaseDownloader

__all__ = [
    "BaseDownloader"
]
